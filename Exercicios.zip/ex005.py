n1 = int(input('Digite um numero'))
#su = n1+1
#ant = n1-1
#print('o sucessor de {0} é {1}, é o antecessor é {2}'.format(n1, su, ant))
print('o sucessor de {} é {}, e o antecessor é {}'.format(n1,(n1+1), (n1-1)))