n1 = float(input('Qual o seu salario? '))

desc = n1*15

resl = desc/100

resul = n1+resl

print('foi aumentado {:.2f} de {:.2f} e ficou {:.2f}'.format(resl, n1, resul))