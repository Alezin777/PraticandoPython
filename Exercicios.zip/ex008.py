metros = float(input('Digite um valor: '))
km = metros/1000
hm = metros/100
dam = metros/10
dm = metros*10
cent = metros*100
mili = metros*1000

print(km, 'km')
print(hm, 'hm')
print(dm, 'dm')
print('Os {0} metros coventidos para centimetros é {1}cm '.format(metros, cent))
print('Os {0} centimetros convertidos para milimetros é {1}'.format(cent, mili))