n = int(input('Digite um numero: '))
do = n * 2
tri = n * 3
rai = n **(1/2) #rai = pow(n, (1/2))

#print('O dobro de {} é {}, o triplo é {} e a raiz quadrada é {:.2f}'.format(n, (n*2), (n*3), (n**(1/2))))
print('O dobro de {} é {}, o triplo é {} e a raiz quadrada é {:.2f}'.format(n, do, tri, rai))