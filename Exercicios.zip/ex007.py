print('CALCULANDO MEDIA')
print('='*20)
n1 = float(input('Digite a primeira nota: '))
n2 = float(input('Digite a segunda nota: '))
n3 = float(input('Digite a terceira nota: '))

media = (n1+n2+n3)/2
print('A media da sua nota é {:.2f}'.format(media))