metros = float(input('Qual a altura da parede? '))
largura = float(input('Qual a largura da parede? '))

cub = metros**largura

litros = 1

area = 2**2

resu = area/litros

resul =  cub%resu

print('Precisamos de {} litros de tinta para pintar esta parede'.format(resul))