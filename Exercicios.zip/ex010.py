reais = float(input('Quantos reais você tem? '))

dolar = reais/3.27

print('Você tem {:.2f} '.format(dolar))