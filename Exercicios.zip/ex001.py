nome = input('digite seu nome ')
print('prazer em te conhecer      {}!'.format(nome))
