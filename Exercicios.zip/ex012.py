n1 = float(input('Qual o preço do produto? '))

desc = n1*5

resl = desc/100

resul = n1-resl

print('foi descontado {:.2f} de {:.2f} e ficou {:.2f}'.format(resl, n1, resul))