num1 = int(input('Digite um numero: '))
num2 = int(input('Outro numero: '))
soma = num1 + num2
print('a soma entre {0} e {1} é {2}!'.format(num1, num2, soma))
